=== WebBird Quotes ===
Contributors: Filip Van Reeth
Requires at least: 4.2.2
Tested up to: 4.2.2
License: WebBird

WebBird Quotes Plugin

== Description ==
WebBird Quotes Plugin

== Installation ==
Required: Advanced Custom Fields 5 plugin.
Just activate and you are ready to go.
